
// src/App.jsx
import React from "react";
import { FaWhatsapp, FaInstagram } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import "./App.css";

export default function App() {
  return (
    <main className="min-h-screen bg-beige-light text-beige-dark font-sans">
      <header className="bg-beige-medium p-6 shadow-md">
        <h1 className="text-3xl font-semibold text-center font-serifElegant">Cilene Costa</h1>
        <p className="text-center text-lg mt-2">Psicanalista</p>
      </header>
      {/* Restante omitido para simplificar */}
      <footer className="text-center p-4 bg-beige-dark text-white">
        © {new Date().getFullYear()} Cilene Costa - Todos os direitos reservados.
      </footer>
    </main>
  );
}
